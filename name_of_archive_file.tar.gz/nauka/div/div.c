
#include <stdlib.h>
#include <stdio.h>

unsigned long int diva(int a, int b, int c);

int main(){
	printf("12 3 0 = %d \n", diva(12,3,0));
	printf("12 5 0 = %d \n", diva(12,5,0));
	printf("12 3 1 = %d \n", diva(12,3,1));
	return 0;
}

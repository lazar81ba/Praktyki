#include <stdlib.h>
#include <stdio.h>

int max_ind(int a, int b, int c, int d);

int main(){
	printf("%d \n", max_ind(1, 4, 4, 2));

	return 0;
}

#include <stdio.h>
#include <stdlib.h>

extern long max_ind(long a, long b, long c,long d);

int main(){
	
	printf("Max_ind dla 1 2 10 5 = %ld \n",max_ind(1,2,10,5));
	printf("Max_ind dla -1 2 3 5 = %ld \n",max_ind(-1,2,3,5));
	printf("Max_ind dla 1 20 10 5 = %ld \n",max_ind(1,20,10,5));
	printf("Max_ind dla 10 2 3 5 = %ld \n",max_ind(10,2,3,5));
	
}

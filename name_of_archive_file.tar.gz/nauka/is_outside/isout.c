#include <stdlib.h>
#include <stdio.h>

long isout(long x, long a, long b);

int main(){
	printf("1 2 3 zwraca = %d\n",isout(1,2,3));
	printf("2 2 3 zwraca = %d\n",isout(2,2,3));
	printf("3 2 3 zwraca = %d\n",isout(3,2,3));
	printf("4 2 3 zwraca = %d\n",isout(4,2,3));
return 0;
}

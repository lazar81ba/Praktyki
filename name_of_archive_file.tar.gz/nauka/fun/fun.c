#include <stdlib.h>
#include <stdio.h>

#define BUFSIZE 100
char *fun(char*buff,char*a,char*b);

int main(){
	char *buff = malloc(BUFSIZE*sizeof(char));
	printf("%s \n",fun ( buff ,  "adzjdp" ,  "nre ua" ));
	return 0;

}

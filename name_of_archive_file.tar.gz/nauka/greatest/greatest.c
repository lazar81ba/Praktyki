#include <stdlib.h>
#include <stdio.h>


long greatest(long a, long b, long c);

int main(){
	printf("Najwieksza z 8 1 2 =%d",greatest(8,1,2));
	printf("Najwieksza z 8 10 2 =%d",greatest(8,10,2));
	printf("Najwieksza z 8 1 20 =%d",greatest(8,1,20));
	return 0;

}

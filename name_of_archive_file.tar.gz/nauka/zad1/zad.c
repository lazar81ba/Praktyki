#include <stdlib.h>
#include <stdio.h>

long max_diff(long a, long b, long c, long d);

int main(){
	printf("%ld \n", max_diff(5, -2, 8, 3));
	
	return 0;
}

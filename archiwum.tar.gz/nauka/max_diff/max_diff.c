#include <stdio.h>
#include <stdlib.h>

extern long max_diff(long a, long b, long c,long d);

int main(){
	
	printf("Max_diff dla 1 2 10 5 = %ld \n",max_diff(1,2,10,5));
	printf("Max_diff dla -1 2 3 5 = %ld \n",max_diff(-1,2,3,5));
	
}
